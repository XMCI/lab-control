=======
Install
=======


Installing from source
======================
  
Clone the `lab-control-lib <https://github.com/optimato/lab-control-lib>`_  
from GitHub::

    git clone https://github.com/optimato/lab-control-lib.git

then::

    $ cd lab-control-lib
    $ pip install .
