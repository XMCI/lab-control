:mod:`lclib.manager`
====================

.. automodule:: lclib.manager
   :members:
   :show-inheritance:
   :undoc-members:

   .. rubric:: **Functions:**

   .. autosummary::
   
