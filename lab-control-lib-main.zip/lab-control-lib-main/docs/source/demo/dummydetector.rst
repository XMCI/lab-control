Dummy Detector
==============

This section contains the dummydetector script.

Download file: :download:`dummydetector.py
<../../../examples/dummylab/dummylab/dummydetector.py>`

.. literalinclude:: ../../../examples/dummylab/dummylab/dummydetector.py
    :tab-width: 4
    :linenos:
    :language: guess

