Dummy Motor
===========

This section contains the dummymotor script.

Download file: :download:`dummymotor.py
<../../../examples/dummylab/dummylab/dummymotor.py>`

.. literalinclude:: ../../../examples/dummylab/dummylab/dummymotor.py
    :tab-width: 4
    :linenos:
    :language: guess

